<form method = "post" action = "ope.php" id = "formlogin" name = "formlogin">
<fieldset>
<legend>Login</legend><br>
<label>NOME: </label>
<input type = "text" name = "user" id = "login" /> <br>
<label> SENHA :</label>
<input type = "password" name = "senha" id = "senha" /><br>
<input type = "submit" value = "logar" />
</fieldset>
</form>