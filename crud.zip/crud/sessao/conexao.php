<?php
    $conectdb = new mysqli('localhost', 'root', '', 'login');

    if (!$conectdb) {
        die("Nao foi possivel conectar: " . mysqli_error(). "<br>");
    }

?>