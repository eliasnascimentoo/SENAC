<html>
<head>
<?php
session_start();
if((!isset ($_SESSION['user']) == true) and (!isset ($_SESSION['senha']) == true))
{
    unset($_SESSSION['user']);
    unset($_SESSION['senha']);
    header('location:index.php');
}
$logado = $_SESSION['user'];
?>
<tittle> SISTEMA WEB </tittle>
</head>
<body>
<?php
echo "bem vindo $logado";
?>
<a href = "logout.php">logout</a>
</body>
</html>