<html>
    <head>
        <title> adicionando.. </title>
    </head>
    <body>
<?php
include('connect.php');
$id = $_POST['id'];
$nome = $_POST['nome'];
$valor = $_POST['valor'];
$cor = $_POST['cor'];
$marca = $_POST['marca'];

echo "id: ".$id."<br>Nome: ".$nome."</br>Valor:".$valor."</br>Cor:".$cor."</br>Marca:".$marca."</br></br>";
$adc="INSERT INTO produtos(id, nome, valor,cor,marca) VALUES('".$id."','".$nome."','".$valor."', '".$cor."', '".$marca."')";
$ins = mysqli_query($conectdb,$adc);
if($ins) {
    echo "Produto adicionado com sucesso! </br><a href='formadd.php'>voltar</a>";
}
else {
    echo "ERRO </br><a href='adicionar.php'>voltar</a>";
}
?>

   </body>
</html>