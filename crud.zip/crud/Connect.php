<?php
$conectdb = new mysqli('localhost','root','','bancoprodutos');

if (!$conectdb){
    die("Não foi possivel conectar:".mysqli_error()."<br>");
}

?>