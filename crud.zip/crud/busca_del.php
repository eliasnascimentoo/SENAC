<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Busca</title>
</head>
<body>
<h1> Agencia de veiculos - SCAV</h1>
<a href="menu.html">Inicio</a> | <a href="formadd.php">Cadastrar</a> | <a href="consulta.php">Consultar</a> | <a href="busca.html">Buscar</a> | <a href="busca_del.php">Deletar</a><p>
    
<h1> Deletar</h1> <hr>

    <form method = "post" action = "del.php">
        Id:<br>
        <input type = "text" name = "id"><br>

        <input type = "submit">
    </form>
</body>
</html>