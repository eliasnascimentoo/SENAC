<?php
        include 'conexao.php';
        $nome = $_POST['nomeproduto'];
        $imagem = $_FILES['imagem'];

        if(isset($_FILES['imagem'])){
            $extensao = strtolower(substr($_FILES['imagem']['name'],-4));
            $imagem = md5(time()).$extensao;
            $diretorio = 'imagem/';
            move_uploaded_file($_FILES['imagem']['tmp_name'],$diretorio.$imagem);
        }

$sql = mysqli_query($conexao,"insert into prodimagem (nomeproduto,imagem) values ('$nome','$imagem')");

        if ($sql) {
            echo "<script>
                    alert ('produto $nome cadastrado com sucesso')
                    location.href='produto.php'
                  </script>";
        }else{
            echo "<script>
                    alert ('produto $nome nao foi cadastrado<br>verifique o erro')
                    location.href='produto.php'
                  </script>";
        }
?>