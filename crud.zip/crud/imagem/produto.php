<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <?php
            include 'menu.php';
    ?>
    <header>
        <h1>Cadastro de produto</h1>
    <header>
    <section>
        <form action="produtoimagem.php" method="POST">
            <table>
                <tr>
                    <td><label id="nome">nome</label></td>
                    <td><input type="text" name="nomeproduto"></td>
                </tr>
                <tr>
                    <td><label id="image">imagem</label></td>
                    <td><input type="file" name="imagem"></td>
                </tr>
                <tr>
        <td><button type= "submit"> cadastrar </button></td>
                <tr>
            <table>
        </form>
    </section>
</body>
</html>