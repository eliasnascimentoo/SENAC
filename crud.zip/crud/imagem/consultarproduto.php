<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <?php
        include 'menu.php';
    ?>
    <header>
        <h1>consultar imagem</h1>
    </header>
    <section>
        <form action="#" method = "post" enctype = "multipart/form-data">
        <label>nome:</label>
        <input type="text" name="nome">
        <button type="submit" name="consultar" class="padrao">consultar</button>
        <br>
    </form>
    <?php

        if (isset($_POST['consultar']){
            include 'conexap.php';
            $nome = $_POST['nome'];
$sql = mysqli_query(conexao,"select * from produto where nomeproduto like '%$nome%'");
        })
        if($sql){
            echo "<table>";
            echo "<tr>
                    <th>codigo do produto</th>
                    <th>nome do produto</th>
                    <th>imagem</th>
                    <th>controle</th>
            </tr>";
            while ($linha = mysqli_fetch_array($sql)){
                echo "<tr>
                    
                    <td>".$linha['idproduto']."</td>
                    <td>".$linha['nomeproduto']."</td>
                    <td><div>
    <img class='produto' src='imagem/".$linha['imagem']."'></div></td>";

    echo"<td>"
    <a href='editarproduto.php?idproduto=".$linha['idproduto']."'></div></td>";
    <button class='excluir'>excluir</button></a>
                                            </td>
                                            </tr>";
                                    }
                                    echo "</table>";
        }else{
            echo "erro ao consultar";
        }
    }
?>
</body>
</html>