<?php
    include ('connect.php');
    $user=$_POST['user'];
    $senha=$_POST['senha'];
    $sql = mysqli_query($conectdb, "select * from tlogin where user = '$user' and senha = '$senha'");
    if(mysqli_num_rows ($sql) > 0){
        header('location: menu.html');
        
        exit();}
        else{
            echo "Usuario ou senha invalidos";
            exit();
    }
    ?>
