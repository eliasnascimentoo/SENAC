<html>
 <head>
   <title> Adicionar </title>
   <meta charset='utf-8'/>
</head>
<body>
 <h1> Agencia de veiculos - SCAV</h1> <hr>
 <a href="menu.html">Inicio</a> | <a href="formadd.php">Cadastrar</a> | <a href="consulta.php">Consultar</a> | <a href="busca.html">Buscar</a> | <a href="busca_del.php">Deletar</a><p>
 <form method = "post" action='incluir.php'>
 Id:<br>
 <input type = "text" name = "id"><br>
 Nome:<br>
 <input type = "text" name = "nome"> <br>
 Valor: <br>
 <input type = "text" name = "valor"> <br>
 Cor: <br>
 <input type = "text" name = "cor"> <br>
 Marca: <br>
 <input type = "text" name = "marca"> <br>
 <input type = "submit">
 </form>
 </doby>
 </html>