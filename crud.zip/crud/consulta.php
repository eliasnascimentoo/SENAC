<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>consulta</title>
</head>
<body>
    <h1> Agencia de veiculos - SCAV</h1>
    <a href="menu.html">Inicio</a> | <a href="formadd.php">Cadastrar</a> | <a href="consulta.php">Consultar</a> | <a href="busca.html">Buscar</a> | <a href="busca_del.php">Deletar</a><p>
    <h1> Consulta </h1>
    <hr>
    
<?php
include('connect.php');
$sql = mysqli_query($conectdb, "select * from produtos");
while($linha = Mysqli_fetch_array($sql)){
    $id = $linha['id'];
    $nome = $linha['nome'];
    $cor = $linha['cor'];
    $marca = $linha['marca'];
    $valor = $linha['valor'];

echo "Id => $id<br>'";
echo "Nome => $nome<br>";
echo "cor => $cor<br>";
echo "marca => $marca<br>";
echo "valor => $valor<br>";
echo "<br><a href='deletar.php?id=".$linha['id']."'>deletar?</a>";
echo "<hr>";

}
?>
</body>
</html>