<h1> Agencia de veiculos - SCAV</h1>
<a href="menu.html">Inicio</a> | <a href="formadd.php">Cadastrar</a> | <a href="consulta.php">Consultar</a> | <a href="busca.html">Buscar</a> | <a href="busca_del.php">Deletar</a><p>
<hr>

<?php
        include('connect.php');
        $id = $_POST['id'];
        $nome = $_POST['nome'];
        $valor = $_POST['valor'];
        $cor = $_POST['cor'];
        $marca = $_POST['marca'];
        
        $sql = mysqli_query($conectdb,"update produtos set nome = '$nome' where id = $id");
        $sql1 = mysqli_query($conectdb,"update produtos set valor = '$valor' where id = $id");
        $sql2 = mysqli_query($conectdb,"update produtos set cor = '$cor' where id = $id");
        $sql3 = mysqli_query($conectdb,"update produtos set marca = '$marca' where id = $id");

        if($sql){
            echo "ok<br>";
            Echo "<a href='editarproduto.php'>voltar</a>";
        }else{
            echo "Não ok";
        }
?>