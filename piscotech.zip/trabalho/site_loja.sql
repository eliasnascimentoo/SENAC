-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 12-Jul-2022 às 01:30
-- Versão do servidor: 10.1.39-MariaDB
-- versão do PHP: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `site_loja`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `productid` varchar(50) NOT NULL,
  `user` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `cart`
--

INSERT INTO `cart` (`id`, `productid`, `user`, `created_at`) VALUES
(28, '10', '2', '2020-12-09 18:52:32'),
(29, '11', '2', '2020-12-09 18:52:33'),
(65, '10', '5', '2022-07-11 23:12:44'),
(66, '11', '5', '2022-07-11 23:12:46');

-- --------------------------------------------------------

--
-- Estrutura da tabela `orderitems`
--

CREATE TABLE `orderitems` (
  `id` int(11) NOT NULL,
  `oid` varchar(50) NOT NULL,
  `ptitle` varchar(50) NOT NULL,
  `price` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `orderitems`
--

INSERT INTO `orderitems` (`id`, `oid`, `ptitle`, `price`) VALUES
(1, '1', 'Casual Style ', '500'),
(2, '2', 'Casual Style ', '500'),
(3, '3', 'Designer Kurtis', '750'),
(4, '3', 'Black & Marron Dhoti Kurta', '1200'),
(5, '4', 'Casual Style ', '500'),
(6, '5', 'Gabinete Gamer Redragon Grapple, Mid Tower, RGB, L', '1'),
(7, '5', 'Red Dragon - Teclado Mecânico', '5'),
(8, '6', 'Smartphone Motorola Moto E20, 32GB, 2GB RAM, Octa ', '739'),
(9, '6', 'Smartphone Xiaomi Redmi Note 11, 4GB RAM, 128GB, O', '1519'),
(10, '6', 'Teclado Mecânico Gamer Redragon Kumara - RGB - Swi', '189'),
(11, '6', 'Mouse Gamer Razer Deathadder Essential', '1000'),
(12, '6', 'Gabinete Gamer Redragon Grapple, Mid Tower, RGB, L', '1'),
(13, '6', 'Headset Gamer Redragon Zeus X, Chroma Mk.II, RGB', '1'),
(14, '6', 'Pen Drive DataTraveler Exodia 64GB Kingston com Co', '1'),
(15, '7', 'Gabinete Gamer Redragon Grapple, Mid Tower, RGB, L', '289'),
(16, '7', 'Notebook Gamer Acer Nitro 5 Intel Core i7-10750H, ', '9400'),
(17, '7', 'Smartphone Xiaomi Redmi Note 11, 4GB RAM, 128GB, O', '1519'),
(18, '8', 'Smartphone Motorola Moto G71, 5G, 6GB RAM, 128GB, ', '1679'),
(19, '8', 'Tablet Samsung Galaxy A7 Lite 4G, 32GB, Android 11', '949'),
(20, '8', 'Mouse Gamer Razer Deathadder Essential', '1000'),
(21, '8', 'Teclado Mecânico Gamer Redragon Kumara - RGB - Swi', '189');

-- --------------------------------------------------------

--
-- Estrutura da tabela `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `nomecartao` varchar(50) NOT NULL,
  `numerocartao` varchar(50) NOT NULL,
  `validade` varchar(50) NOT NULL,
  `cvc` varchar(50) NOT NULL,
  `pagamento` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `orders`
--

INSERT INTO `orders` (`id`, `user`, `address`, `created_at`, `nomecartao`, `numerocartao`, `validade`, `cvc`, `pagamento`) VALUES
(5, '3', 'teste', '2022-07-11 22:03:44', 'teste', 'teste', 'teste', 'teste', 'Crédito'),
(6, '4', 'Estrada da posse', '2022-07-11 22:51:06', 'Julio boladão', '24242424', '10/23', '444', 'Crédito'),
(7, '4', 'Estrada da posse', '2022-07-11 23:25:31', 'Julio boladão', '2121213216541541515', '253', '001', 'Crédito'),
(8, '4', 'Estrada da posse', '2022-07-11 23:27:07', 'asdasdas', '21213235646464', '665', '333', 'Débito');

-- --------------------------------------------------------

--
-- Estrutura da tabela `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `img` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `products`
--

INSERT INTO `products` (`id`, `title`, `price`, `img`, `category`, `created_at`) VALUES
(1, 'Teclado Mecânico Gamer Redragon Kumara - RGB - Swi', '189', 'teclado1.jpg', 'Periférico', '2020-12-09 01:40:06'),
(2, 'Mouse Gamer Razer Deathadder Essential', '1000', 'mouse1.jpg', 'Periférico', '2020-12-09 01:40:06'),
(3, 'Gabinete Gamer Redragon Grapple, Mid Tower, RGB, L', '289', 'gabinete1.jpg', 'Periférico', '2020-12-09 02:29:46'),
(4, 'Headset Gamer Redragon Zeus X, Chroma Mk.II, RGB', '600', 'headset1.jpg', 'Periférico', '2020-12-09 02:46:10'),
(5, 'Caixa de Som Gamer Husky Gaming Storm, Preto, 6W, ', '60', 'caixadesom.jpg', 'Periférico', '2020-12-09 02:49:43'),
(6, 'Mousepad Gamer Husky Black Avalanche, Speed, Extra', '35', 'mousepad1.jpg', 'Periférico', '2020-12-09 02:49:43'),
(7, 'Pen Drive DataTraveler Exodia 64GB Kingston com Co', '50', 'pendrive.jpg', 'Periférico', '2020-12-09 02:52:06'),
(8, 'Kit Tira de LED Corsair RGB iCUE LS100 Smart Light', '1400', 'luz.jpg', 'Periférico', '2022-07-09 02:53:40'),
(9, 'Notebook Asus AMD Ryzen 5-3500U, 8GB RAM, SSD 256G', '4400', 'notebook1.jpg', 'Computador', '2020-12-09 02:56:29'),
(10, 'Notebook Acer Aspire 5 Ryzen 7-5700U, 8GB RAM, 256', '4200', 'notebook2.jpg', 'Computador', '2020-12-09 02:58:11'),
(11, 'Notebook Gamer Acer Nitro 5 Intel Core i7-10750H, ', '9400', 'notebook3.jpg', 'Computador', '2020-12-09 03:00:21'),
(12, 'PC Gamer OnGaming Powered By Asus Intel Core i7-12', '10000', 'computador1.jpg', 'Computador', '2020-12-09 03:01:29'),
(13, 'PC Gamer Skul 3000 I3-10100F, Radeon RX 550, 8GB D', '1700', 'computador2.jpg', 'Computador', '2020-12-09 03:03:33'),
(14, 'PC Gamer Skul 5000 I5-10400F, Geforce GTX 1650, 16', '3500', 'computador3.jpg', 'Computador', '2020-12-09 03:05:17'),
(15, 'PC Gamer Concórdia Core i7-10700F, Geforce RTX3060', '4500', 'computador4.jpg', 'Computador', '2020-12-09 03:07:05'),
(16, 'PC Gamer BRX Powered By Asus, Intel Core i5-9400F,', '4700', 'computador5.jpg', 'Computador', '2020-12-09 03:08:13'),
(17, 'Smartphone Motorola Moto G71, 5G, 6GB RAM, 128GB, ', '1679', 'celular01.jpg', 'Mobile', '2020-12-09 03:09:21'),
(18, 'Smartphone Motorola Moto E20, 32GB, 2GB RAM, Octa ', '739', 'celular2.jpg', 'Mobile', '2020-12-09 03:10:27'),
(19, 'Smartphone Samsung Galaxy M12 64GB, 4GB RAM, Octa-', '1044', 'celular3.jpg', 'Mobile', '2020-12-09 03:11:33'),
(20, 'Smartphone Xiaomi Redmi Note 11, 4GB RAM, 128GB, O', '1519', 'celular02.jpg', 'Mobile', '2020-12-09 03:13:02'),
(21, 'Tablet Samsung Galaxy A7 Lite 4G, 32GB, Android 11', '949', 'tablet1.jpg', 'Mobile', '2020-12-09 03:14:09'),
(22, 'Tablet Samsung Galaxy Tab S6 Lite, 4G, Bluetooth, ', '2199', 'tablet2.jpg', 'Mobile', '2020-12-09 03:15:49'),
(23, 'Kindle 10ª Geração, Preto, Luz Integrada, Wi-Fi, 8', '399', 'tablet3.jpg', 'Mobile', '2020-12-09 03:21:24'),
(24, 'Tablet Positivo Twist Tab, Android Oreo Go Edition', '319', 'tablet03.jpg', 'Mobile', '2020-12-09 03:23:04');

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `mobile`, `password`, `created_at`) VALUES
(3, 'Flavio', 'flavio@gmail.com', '2197979779', '202cb962ac59075b964b07152d234b70', '2022-07-08 22:48:31'),
(4, 'julio', 'julio@gmail.com', '2164565465', '202cb962ac59075b964b07152d234b70', '2022-07-11 22:48:47'),
(5, 'felipe', 'Felipe@gmail.com', '21988888888', '202cb962ac59075b964b07152d234b70', '2022-07-11 23:11:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orderitems`
--
ALTER TABLE `orderitems`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `orderitems`
--
ALTER TABLE `orderitems`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
