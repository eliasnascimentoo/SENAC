<div class="container-fluid bg-dark">
    <div class="container">
        <nav class="navbar navbar-expand-md navbar-dark bg-dark p-4">
            <a class="navbar-brand mr-5 font-weight-bold" href="index.php"><img style = "margin-right: -20px;" width = "200" src="https://i.ibb.co/dPYYCzp/Pisco-Banner-paisagem-72-30-in-72-25-in.png"></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarsExampleDefault">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link font-weight-bold" href="index.php">Início</a>
                    </li>
                    <li class="nav-item ml-2 active">
                        <a class="nav-link font-weight-bold" href="periferico.php">Periféricos</a>
                    </li>
                    <li class="nav-item ml-2 active">
                        <a class="nav-link font-weight-bold" href="computador.php">Computadores</a>
                    </li>
                    <li class="nav-item ml-2 active">
                        <a class="nav-link font-weight-bold" href="mobile.php">Tablets/Smartphones</a>
                    </li>

                </ul>

                <ul class="navbar-nav">
                    <li class="nav-item active">
                        <a class="nav-link" href="mycart.php"> <i class="fa fa-shopping-cart"></i> Meu carrinho</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link"> | </a>
                    </li>

                    <?php if (strlen(isset($_SESSION['login']) == 0)){ ?>
                        <li class="nav-item active">
                            <a class="nav-link" href="login.php">Entrar / Cadastrar</a>
                        </li>
                    <?php } else { ?>
                        <li class="nav-item active">
                            <a class="nav-link" href="#"><i class="fa fa-user"></i> Bem-vindo, <?php echo $_SESSION['login'] ?></a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="logout.php"><b>Sair</b></a>
                        </li>
                    <?php } ?>

                </ul>
            </div>
        </nav>
    </div>
</div>