<footer class="container-fluid p-4 clearfix">
    <div class="container clearfix">
        <a class="float-left text-dark" href="terms.php">Termos & Condições</a>
        
        <p class="float-right">Copyright © 2022 |  Feito por:  <b>Elias Andrade, Felipe Rocha, Flávio Cezar e Ygor Oliveira</b> </p>
    </div>  
</footer>