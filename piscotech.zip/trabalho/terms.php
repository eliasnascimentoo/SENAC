<?php
session_start();
error_reporting(0);
include('config.php');

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Piscotech</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="./css/style.css">
</head>
<body>

    <section>
        <?php include('./inc/header.php') ;?> 
       
            <div class="container my-5">
                <h3 class="py-4">Termos e Condições</h3>
                <div class="row">

                <p>A divulgação da Propriedade Intelectual informará aos usuários que o conteúdo, logotipo e outras mídias visuais que você criou são de sua propriedade e estão protegidos por leis de direitos autorais.</p>
                
                <p>Uma cláusula de rescisão informará que as contas dos usuários em seu site e aplicativo para dispositivos móveis ou o acesso dos usuários ao seu site e dispositivos móveis (se os usuários não puderem ter uma conta com você) podem ser encerrados em caso de abusos ou por sua conta discrição.</p>
                <p>Uma lei aplicável informará aos usuários quais leis regem o contrato. Deve ser o país em que sua empresa está sediada ou o país em que você opera seu site e aplicativo para dispositivos móveis.</p>
                <p>Uma cláusula de links para outros sites da Web informará aos usuários que você não é responsável por nenhum site de terceiros para o qual você vincule. Esse tipo de cláusula geralmente informará aos usuários que eles são responsáveis ​​por ler e concordar (ou discordar) com os Termos e Condições ou Políticas de Privacidade desses terceiros.</p>
                <p>Se seu site ou aplicativo móvel permitir que os usuários criem conteúdo e tornem esse conteúdo público para outros usuários, uma seção de conteúdo informará aos usuários que eles possuem os direitos sobre o conteúdo que criaram. A cláusula "Conteúdo" geralmente menciona que os usuários devem fornecer a você (o desenvolvedor do site ou do aplicativo para dispositivos móveis) uma licença para que você possa compartilhar esse conteúdo em seu site/aplicativo para dispositivos móveis e disponibilizá-lo para outros usuários.</p>

                <p>Because the content created by users is public to other users, a DMCA notice clause (or Copyright Infringement ) section is helpful to inform users and copyright authors that, if any content is found to be a copyright infringement, you will respond to any DMCA takedown notices received and you will take down the content.</p>

                <p>Uma cláusula Limit What Users Can Do pode informar aos usuários que, ao concordar em usar seu serviço, eles também concordam em não fazer certas coisas. Isso pode fazer parte de uma lista muito longa e completa em seus acordos de Termos e Condições para abranger a maior quantidade de usos negativos.
                Veja como o 500px lista suas atividades proibidas:</p>

                <p>Termos de uso do 500px: trecho da cláusula de conduta do usuário - atividades proibidas</p>

                <p>Você também pode usar seus T&C para informar os usuários sobre marcas registradas, direitos de design e outros direitos de propriedade intelectual:</p>

                <p>Termos de uso do 500px: cláusula de marcas registradas</p>

                <p>Se você opera um aplicativo SaaS, uma "cláusula de rescisão" será muito importante. O relacionamento com seus clientes pode terminar por vários motivos, desde uma mudança de carreira do cliente até a disponibilização de uma nova e melhor opção de SaaS ou apenas insatisfação geral com um serviço.</p>

                <p>Mas, como proprietário do aplicativo, você deve ter </p>
              </div>
        </div>
    
        <?php include('./inc/footer.php') ;?> 
    </section>
        
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>