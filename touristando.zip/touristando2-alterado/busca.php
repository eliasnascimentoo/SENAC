<?php
include('connect.php');
$id = $_POST['cpf'];
$sql = mysqli_query($conexao, "select * from cadastro where cpf = '$cpf'");
while($linha = Mysqli_fetch_array($sql)){
    $id = $linha['id'];
    $nome = $linha['nome'];
    $cor = $linha['cor'];
    $marca = $linha['marca'];
    $valor = $linha['valor'];

echo "Id => $id<br>'";
echo "Nome => $nome<br>";
echo "cor => $cor<br>";
echo "marca => $marca<br>";
echo "valor => $valor<br>";
echo "<br><a href ='editarproduto.php?id=".$linha['id']."'>editar</a>";
echo "<br><a href='deletar.php?id=".$linha['id']."'>deletar?</a>";
echo "<hr>";
}
echo "<a href='busca.html'>Buscar Novamente</a>";
?>