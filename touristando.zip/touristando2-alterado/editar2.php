<?php
        include('connect.php');
        $nome = $_POST['nome'];
        $sobrenome = $_POST['sobrenome'];
        $email = $_POST['email'];
        $senha = $_POST['senha'];
        $datanasc = $_POST['nascimento'];
        $celular = $_POST['celular'];
        $cpf = $_POST['cpf'];
        $rg = $_POST['rg'];
        $cep = $_POST['cep'];
        $rua = $_POST['rua'];
        $numero = $_POST['numero'];
        $bairro = $_POST['bairro'];
        $genero = $_POST['genero'];
        
        $sql = mysqli_query($conexao,"update cadastro set nome = '$nome' where cpf = $cpf");
        $sql2 = mysqli_query($conexao,"update cadastro set sobrenome = '$sobrenome' where cpf = $cpf");
        $sql3 = mysqli_query($conexao,"update cadastro set email = '$email' where cpf = $cpf");
        $sql4 = mysqli_query($conexao,"update cadastro set senha = '$senha' where cpf = $cpf");
        $sql5 = mysqli_query($conexao,"update cadastro set nascimento = '$datanasc' where cpf = $cpf");
        $sql6 = mysqli_query($conexao,"update cadastro set celular = '$celular' where cpf = $cpf");
        $sql7 = mysqli_query($conexao,"update cadastro set cpf = '$cpf' where cpf = $cpf");
        $sql8 = mysqli_query($conexao,"update cadastro set rg = '$rg' where cpf = $cpf");
        $sql9 = mysqli_query($conexao,"update cadastro set cep = '$cep' where cpf = $cpf");
        $sql10 = mysqli_query($conexao,"update cadastro set rua = '$rua' where cpf = $cpf");
        $sql11 = mysqli_query($conexao,"update cadastro set numero = '$numero' where cpf = $cpf");
        $sql12 = mysqli_query($conexao,"update cadastro set bairro = '$bairro' where cpf = $cpf");
        $sql13 = mysqli_query($conexao,"update cadastro set genero = '$genero' where cpf = $cpf");

        if($sql){
            echo "ok<br>";
            Echo "<a href='alterar.php'>voltar</a>";
        }else{
            echo "Não ok";
        }
?>