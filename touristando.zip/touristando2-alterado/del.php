<h1> TOURISTANDO</h1>
<hr>
<?php
include('connect.php');
$cpf = $_POST['cpf'];
$sql = mysqli_query($conexao,"select * from cadastro where cpf = '$cpf'");
while($linha = mysqli_fetch_array($sql)){

$nome = $linha['nome'];
$sobrenome = $linha['sobrenome'];
$email = $linha['email'];
$senha = $linha['senha'];
$datanasc = $linha['datanascimento'];
$celular = $linha['celular'];
$cpf = $linha['cpf'];
$rg = $linha['rg'];
$cep = $linha['cep'];
$rua = $linha['rua'];
$numero = $linha['numero'];
$bairro = $linha['bairro'];
$genero = $linha['genero'];

    echo "Nome => $nome<br>";
    echo "Sobrenome => $sobrenome<br>";
    echo "email => $email<br>";
    echo "senha => $senha<br>";
    echo "Nascimento => $datanasc<br>";
    echo "Celular => $celular<br>";
    echo "CPF => $cpf<br>";
    echo "RG => $rg<br>";
    echo "CEP => $cep<br>";
    echo "Rua => $rua<br>";
    echo "Numero => $numero<br>";
    echo "Bairro => $bairro<br>";
    echo "Genero => $genero<br>";


//envio do dados para deletar
echo "Deseja deletar o cadastro? ".$nome."</br></br>";
echo "<a href='deletar.php?cpf=".$cpf."'>sim</a>";
}
echo "<br>";
Echo "<a href='busca_del.php'>voltar</a>";
?>