<?php
include('connect.php');
$sql = mysqli_query($conexao, "select * from cadastro");
while($linha = Mysqli_fetch_array($sql)){
$nome = $linha['nome'];
$sobrenome = $linha['sobrenome'];
$email = $linha['email'];
$senha = $linha['senha'];
$datanasc = $linha['datanascimento'];
$celular = $linha['celular'];
$cpf = $linha['cpf'];
$rg = $linha['rg'];
$cep = $linha['cep'];
$rua = $linha['rua'];
$numero = $linha['numero'];
$bairro = $linha['bairro'];
$genero = $linha['genero'];

echo "Nome => $nome<br>";
echo "Sobrenome => $sobrenome<br>";
echo "Email => $email<br>";
echo "Senha => $senha<br>";
echo "Data de Nascimento => $datanasc<br>";
echo "Celular => $celular<br>";
echo "Cpf => $cpf<br>";
echo "Rg => $rg<br>";
echo "Cep => $cep<br>";
echo "Rua => $rua<br>";
echo "Número => $numero<br>";
echo "Bairro => $bairro<br>";
echo "Gênero => $genero<br>";
echo "<br><a href ='alterar.php?cpf=".$linha['cpf']."'>editar</a>";
echo "<hr>";


}
?>

