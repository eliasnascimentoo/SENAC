<?php
include('connect.php');
$sql = mysqli_query($conexao, "select * from cadastro");
while($linha = Mysqli_fetch_array($sql)){
$nome = $linha['nome'];
$sobrenome = $linha['sobrenome'];
$email = $linha['email'];
$senha = $linha['senha'];
$datanasc = $linha['datanascimento'];
$celular = $linha['celular'];
$cpf = $linha['cpf'];
$rg = $linha['rg'];
$cep = $linha['cep'];
$rua = $linha['rua'];
$numero = $linha['numero'];
$bairro = $linha['bairro'];
$genero = $linha['genero'];
}
?>