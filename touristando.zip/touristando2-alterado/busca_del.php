<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Busca</title>
</head>
<body>
<h1> TOURISTANDO</h1>
    
<h1> Deletar</h1> <hr>

    <form method = "post" action = "del.php">
        CPF:<br>
        <input type = "text" name = "cpf"><br>

        <input type = "submit">
    </form>
</body>
</html>