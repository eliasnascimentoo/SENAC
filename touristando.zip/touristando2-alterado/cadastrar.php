<?php
include('connect.php');
$nome = $_POST['nome'];
$sobrenome = $_POST['sbname'];
$email = $_POST['email'];
$senha = $_POST['senha'];
$datanasc = $_POST['nascimento'];
$celular = $_POST['celular'];
$cpf = $_POST['cpf'];
$rg = $_POST['rg'];
$cep = $_POST['cep'];
$rua = $_POST['rua'];
$numero = $_POST['numero'];
$bairro = $_POST['bairro'];
$genero = $_POST['genero'];

$adc = "INSERT INTO 
cadastro(nome,sobrenome,email,senha,datanascimento,celular,cpf,rg,cep,rua,numero,bairro,genero) 
VALUES ('".$nome."','".$sobrenome."','".$email."','".$senha."','".$datanasc."','".$celular."','".$cpf."','".$rg."'
,'".$cep."','".$rua."','".$numero."','".$bairro."','".$genero."')";

$ins = mysqli_query($conexao,$adc);
if($ins){
    header('location: cadastrosucesso.html');

}else{
    echo "Erro<br>";
}
?>