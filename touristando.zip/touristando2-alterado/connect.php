<?php
$conexao = new mysqli('localhost','root','','agenciadeviagem');
if(!$conexao){
    die("Não foi possível conectar: " .mysqli_error()."<br>");
}

?>