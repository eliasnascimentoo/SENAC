<body>

    <section>
        <?php
            include('connect.php');
            $cpf = $_GET['cpf'];
            $sql = mysqli_query($conexao,"select * from cadastro where cpf = '$cpf'");
            $linha = mysqli_fetch_array($sql);

                if ($linha){
                    echo "<form action = 'alterar2.php' method = 'post'>
                        <table>
                            <tr>
                            <td><label>id</label></td>
    <td><input type = 'text' name = 'nome' value = '".$linha["nome"]."'></td>
                            </tr>
                            <tr>
<td><label>nome</label></td>
<td><input type='text' name = 'sobrenome' value='".$linha["sobrenome"]."'></td></tr>
<tr><td><label>valor</label></td>
<td><input type = 'text' name = 'email' value = '".$linha["email"]."'></td></tr>
<tr><td><label>cor</label></td>
<td><input type = 'text' name = 'senha' value = '".$linha["senha"]."'></td></tr>
<tr><td><label>marca</label></td>
<td><input type = 'text' name = 'nascimento' value = '".$linha["datanasc"]."'></td></tr>
<td><label>nome</label></td>
<td><input type='text' name = 'celular' value='".$linha["celular"]."'></td></tr>
<td><label>nome</label></td>
<td><input type='text' name = 'cpf' value='".$linha["cpf"]."'></td></tr>
<td><label>nome</label></td>
<td><input type='text' name = 'rg' value='".$linha["rg"]."'></td></tr>
<td><label>nome</label></td>
<td><input type='text' name = 'cep' value='".$linha["cep"]."'></td></tr>
<td><label>nome</label></td>
<td><input type='text' name = 'rua' value='".$linha["rua"]."'></td></tr>
<td><label>nome</label></td>
<td><input type='text' name = 'numero' value='".$linha["numero"]."'></td></tr>
<td><label>nome</label></td>
<td><input type='text' name = 'bairro' value='".$linha["bairro"]."'></td></tr>
<td><label>nome</label></td>
<td><input type='text' name = 'genero' value='".$linha["genero"]."'></td></tr>

                            </tr>
                            <tr>
<td><button type ='submit'>Editar</button></td>
                            </tr>
                        </table>
                    </form>";
                }else{
                    echo "dados não encontrados";
}
                          ?>
                    </section>                
</body>
</html>