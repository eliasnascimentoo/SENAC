
<?php
session_start();
$email = $_POST['email'];
$senha = $_POST['senha'];
include('connect.php');
$sql = mysqli_query($conexao, "SELECT * from cadastro where email = '$email' AND senha = '$senha'");
if(mysqli_num_rows($sql) > 0){

    $_SESSION['email'] = $email; 
    $_SESSION['senha'] = $senha;
    $_SESSION['nome'] = $nome; 
    header('location: index2.php');
}
else{
    unset($_SESSION['email']);
    unset($_SESSION['senha']);
    header('location: login.html');
}
?>