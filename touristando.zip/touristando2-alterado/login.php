<?php
    include('connect.php');
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $sql = mysqli_query($conexao, "select * from cadastro where email = '$email' and senha = '$senha'");
    if(mysqli_num_rows($sql) > 0){
        echo "Senha correta"
        exit(); }
        else{
            echo "Usuário ou senha inválidos";
            exit();

        }
        ?>