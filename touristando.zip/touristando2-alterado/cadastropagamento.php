<?php
include('connect.php');
$nome = $_POST['nome'];
$sobrenome = $_POST['sobrenome'];
$email = $_POST['email'];
$pacote = $_POST['pacote'];
$pagamento = $_POST['metodopagamento'];
$nomecartao = $_POST['nomenocartao'];
$numerocartao = $_POST['numerodocartao'];
$vencimento = $_POST['vencimento'];
$cvc = $_POST['cvc'];

$adc = "INSERT INTO 
pagamento(nome,sobrenome,email,tipopagamento,nomecartao,numerocartao,vencimento,cvc,pacote) 
VALUES ('".$nome."','".$sobrenome."','".$email."','".$pagamento."','".$nomecartao."','".$numerocartao."','".$vencimento."','".$cvc."'
,'".$pacote."')";

$ins = mysqli_query($conexao,$adc);
if($ins){
    header('location: pagamentosucesso.html');

}else{
    echo "Erro<br>";
}
?>