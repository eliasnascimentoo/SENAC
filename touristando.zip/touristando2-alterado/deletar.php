<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Deletando</title>
</head>
<body>
<h1> TOURISTADNO</h1>

<?php
include('connect.php');
$cpf = $_GET['cpf'];
echo "deletando o cadastro de codigo <br>".$cpf."</br></br></br>";
$query = "delete from cadastro where cpf = '$cpf'";
$result = $conexao->query($query);
if($result){
    echo "Deletado com sucesso!<br>";
} else {
    echo "Erro</br><a href='##'>Voltar<a/>";
}
?>
</body>
</html>