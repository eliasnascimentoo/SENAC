-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 04-Jun-2022 às 21:50
-- Versão do servidor: 10.4.24-MariaDB
-- versão do PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `agenciadeviagem`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cadastro`
--

CREATE TABLE `cadastro` (
  `nome` varchar(50) NOT NULL,
  `sobrenome` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `senha` varchar(20) NOT NULL,
  `datanascimento` date NOT NULL,
  `celular` varchar(20) NOT NULL,
  `cpf` varchar(11) NOT NULL,
  `rg` varchar(11) NOT NULL,
  `cep` varchar(20) NOT NULL,
  `rua` varchar(30) NOT NULL,
  `numero` varchar(10) NOT NULL,
  `bairro` varchar(30) NOT NULL,
  `genero` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `cadastro`
--

INSERT INTO `cadastro` (`nome`, `sobrenome`, `email`, `senha`, `datanascimento`, `celular`, `cpf`, `rg`, `cep`, `rua`, `numero`, `bairro`, `genero`) VALUES
('Luiz', 'Almeida', 'luiz@gmail.com', '123', '1994-11-19', '21979427271', '11111111', '212121212', '321', 'Estrada da Posse', '54', 'Santíssimo', 'masculino'),
('Pedro', 'Rodrigues', 'pedro@gmail.com', '', '1994-11-19', '212321324', '56666', '448948', '21321', 'Almeida', '45', 'santos', 'masculino');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pagamento`
--

CREATE TABLE `pagamento` (
  `nome` varchar(50) NOT NULL,
  `sobrenome` varchar(50) NOT NULL,
  `email` varchar(20) NOT NULL,
  `tipopagamento` varchar(10) NOT NULL,
  `nomecartao` varchar(30) NOT NULL,
  `numerocartao` varchar(40) NOT NULL,
  `vencimento` varchar(20) NOT NULL,
  `cvc` varchar(10) NOT NULL,
  `pacote` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `pagamento`
--

INSERT INTO `pagamento` (`nome`, `sobrenome`, `email`, `tipopagamento`, `nomecartao`, `numerocartao`, `vencimento`, `cvc`, `pacote`) VALUES
('TESTANDO', '', 'vamostestar@gmail.co', 'crédito', 'Testandotu', '635165165', '12/23', '444', 'pacoterj'),
('TESTANDO', 'TETANDO', 'vamostestar@gmail.co', 'crédito', 'Testandotu', '635165165', '12/23', '444', 'pacoterj'),
('Testando', 'novamente', 'vamostestar@gmail.co', 'débito', 'Vamostestar', '9876546231', '12/12', '222', 'pacotepe');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `cadastro`
--
ALTER TABLE `cadastro`
  ADD PRIMARY KEY (`cpf`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
