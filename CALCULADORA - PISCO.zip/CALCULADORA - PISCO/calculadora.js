class Calculadora{
    constructor(){
        this.upperValue = document.querySelector('#upper-number');
        this.resultValue = document.querySelector('#result-number');
        this.reset = 0;
    }
    limparValores(){
        this.upperValue.textContent = '0';
        this.resultValue.textContent = '0';
    }

    verificarUltimoDigito(input, upperValue, reg){
        if((!reg.test(input) && !reg.test(upperValue.substr(upperValue.lenght -1)))){
            return true;
        } else{
            return false;
        }
            
    }

somar(n1,n2){
    return parseFloat(n1) + parseFloat(n2);
}

subtrair(n1,n2){
    return parseFloat(n1) - parseFloat(n2);
}

multiplicar(n1,n2){
    return parseFloat(n1) * parseFloat(n2);
}

divisao(n1,n2){
    return parseFloat(n1) / parseFloat(n2);
}

atualizarValores(total){
    this.upperValue.textContent = total;
    this.resultValue.textContent = total;
}

resolucao(){

}
}

let upperValueArray =(this.upperValue.textContent).split(" ");
let resultado = 0;
for(let i = 0; i <= upperValueArray.lenght; i++){
let operacao = 0;
let itemAtual = upperValueArray[i];

if(itemAtual == "x"){
    resultado = calc.multiplicacao(upperValueArray[i-1], upperValueArray[i+1]);
}else if(itemAtual == "/"){
    resultado = calc.divisao(upperValueArray[i-1], upperValueArray[i+1]);
}else if(!upperValueArray.includes('x') && !upperValueArray.includes('/')){
    if(itemAtual == "+"){
        resultado = calc.somar(upperValueArray[i-1], upperValueArray[i+1]);
        operacao = 1;
    }else if(itemAtual == "-"){
        resultado = calc.subtrair(upperValueArray[i-1], upperValueArray[i+1]);
        operacao = 1;
    }
}


if(operacao){
    upperValueArray[i - 1] = resultado;
    upperValue.splice(i, 2);
    i = 0;
}

btnPress();{
    let input = this.textContent;
    let upperValue = calc.upperValue.textContent;
    var reg = new RegExp('^\\d+$');
    if(calc.reset && reg.test(input)){
        upperValue = '0';
    }
    calc.reset = 0;

    if(input == 'AC'){
        calc.limparValores();
    }else if(input == "="){
        calc.resolucao();
    }else{
        if(calc.verificarUltimoDigito(input,upperValue,reg)){
            return false;
        }

        if(!reg.test(input)){
            input = '$[input]';
        }
        if(upperValue == "0"){
            if(reg.test(input)){
                calc.upperValue.textContent = input;
            }
        } else {
            calc.upperValue.textContent += input;
        }
    } if(resultado){
        calc.reset = 1;
    }

    calc.atualizarValores(resultado);
    let calc = new Calculadora;
    let botoes = document.querySelectorAll('.btn');
    for(let i = 0; botoes.length > i; i++) {
        botoes[i].addEventListener('click', calc.btnPress);

    }

}
}
