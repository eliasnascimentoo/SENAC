<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<h1> Agencia de veiculos - SCAV</h1>
        <a href = "menu.php">Início</a> | <a href = "formcadastrarfuncionario.php">Cadastrar Funcionário</a> |<a href = "formcadastrarproduto.php">Cadastrar Produto</a> | <a href = "consultafuncionario.php">Consultar Funcionário</a> | <a href = "consultaproduto.php">Consultar Produto</a> | <a href = "buscafuncionario.html">Buscar Funcionario</a>  | <a href = "buscaproduto.html">Buscar Produto</a> | <a href = "#">Alterar Funcionário</a> | <a href = "#">Alterar Produto</a> | <a href = "#">Excluir</a> | <a href = "logout.php">Logout</a>
<hr>
    <header>
        <h1>Editar Funcionario</h1>
    </header>
    <section>
        <?php
            include('connect.php');
            $codfuncionario = $_GET['codfuncionario'];
            $sql = mysqli_query($conexao,"select * from funcionario where codfuncionario = '$codfuncionario'");
            $linha = mysqli_fetch_array($sql);
                if ($linha){
                    echo "<form action = 'alterarfuncionario2.php' method = 'post'>
                        <table>
                            <tr>
                            <td><label>codfuncionario</label></td>
    <td><input type = 'text' name = 'codfuncionario' value = '".$linha["codfuncionario"]."'></td>
                            </tr>
                            <tr>
<td><label>nome</label></td>
<td><input type='text' name = 'nome' value='".$linha["nome"]."'></td></tr>
<tr><td><label>cpf</label></td>
<td><input type = 'text' name = 'cpf' value = '".$linha["cpf"]."'></td></tr>
<tr><td><label>telefone</label></td>
<td><input type = 'text' name = 'telefone' value = '".$linha["telefone"]."'></td></tr>
<tr><td><label>setor</label></td>
<td><input type = 'text' name = 'setor' value = '".$linha["setor"]."'></td></tr>
                            </tr>
                            <tr>
<td><button type ='submit'>Editar</button></td>
                            </tr>
                        </table>
                    </form>";
                }else{
                    echo "dados não encontrados";

}

                          ?>

                    </section>                

</body>

</html>