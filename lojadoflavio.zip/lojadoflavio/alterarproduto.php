<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <header>
        <h1>Editar Produto</h1>
    </header>
    <section>
        <?php
            include('connect.php');
            $codproduto = $_GET['codproduto'];
            $sql = mysqli_query($conexao,"select * from estoque where codproduto = '$codproduto'");
            $linha = mysqli_fetch_array($sql);
                if ($linha){
                    echo "<form action = 'alterarproduto2.php' method = 'post'>
                        <table>
                            <tr>
                            <td><label>codproduto</label></td>
    <td><input type = 'text' name = 'codproduto' value = '".$linha["codproduto"]."'></td>
                            </tr>
                            <tr>
<td><label>nome</label></td>
<td><input type='text' name = 'nome' value='".$linha["nome"]."'></td></tr>
<tr><td><label>fabricante</label></td>
<td><input type = 'text' name = 'fabricante' value = '".$linha["fabricante"]."'></td></tr>
<tr><td><label>validade</label></td>
<td><input type = 'text' name = 'validade' value = '".$linha["validade"]."'></td></tr>
<tr><td><label>valor</label></td>
<td><input type = 'text' name = 'valor' value = '".$linha["valor"]."'></td></tr>
                            </tr>
                            <tr>
<td><button type ='submit'>Editar</button></td>
                            </tr>
                        </table>
                    </form>";
                }else{
                    echo "dados não encontrados";

}

                          ?>

                    </section>                

</body>

</html>