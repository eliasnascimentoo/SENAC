<?php
include('menu.php');
include('connect.php');
$sql = mysqli_query($conexao, "select * from funcionario");
while($linha = Mysqli_fetch_array($sql)){
    $codfuncionario = $linha['codfuncionario'];
    $nome = $linha['nome'];
    $cpf = $linha['cpf'];
    $telefone = $linha['telefone'];
    $setor = $linha['setor'];

echo "<table border = 1><tr><td>Código do Funcionário </td><td> $codfuncionario</td></tr>";
echo "<tr><td>Nome </td>  <td> $nome</td></tr>";
echo "<tr><td>CPF </td> <td> $cpf</td></tr>";
echo "<tr><td>Telefone </td> <td> $telefone</td></tr>";
echo "<tr><td>Setor </td> <td> $setor</td></tr></table>";
echo "<br><a href ='alterarfuncionario.php?codfuncionario=".$linha['codfuncionario']."'>editar</a>";
echo "<br><a href='deletarfuncionario.php?codfuncionario=".$linha['codfuncionario']."'>deletar?</a>";
echo "<hr>";
}
?>