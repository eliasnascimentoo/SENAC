<?php
include('menu.php');
include('connect.php');
$sql = mysqli_query($conexao, "select * from estoque");
while($linha = Mysqli_fetch_array($sql)){
    $codproduto = $linha['codproduto'];
    $nome = $linha['nome'];
    $fabricante = $linha['fabricante'];
    $validade = $linha['validade'];
    $valor = $linha['valor'];

echo "<table border = 1><tr><td>Código do Produto </td><td> $codproduto</td>";
echo "<td>Nome </td>  <td> $nome</td>";
echo "<td>Fabricante </td> <td> $fabricante</td>";
echo "<td>Validade </td> <td> $validade</td>";
echo "<td>Valor </td> <td> $valor</td>";
echo "<td><a href ='alterarproduto.php?codproduto=".$linha['codproduto']."'>editar</a></td>";
echo "<td><a href='deletarproduto.php?codproduto=".$linha['codproduto']."'>deletar?</a></td></tr></table>";

}
?>