<?php
        include('menu.php');
        include('connect.php');
        $codproduto = $_POST['codproduto'];
        $nome = $_POST['nome'];
        $fabricante = $_POST['fabricante'];
        $validade = $_POST['validade'];
        $valor = $_POST['valor'];

        $sql = mysqli_query($conexao,"update estoque set nome = '$nome' where codproduto = $codproduto");
        $sql1 = mysqli_query($conexao,"update estoque set fabricante = '$fabricante' where codproduto = $codproduto");
        $sql2 = mysqli_query($conexao,"update estoque set validade = '$validade' where codproduto = $codproduto");
        $sql3 = mysqli_query($conexao,"update estoque set valor = '$valor' where codproduto = $codproduto");

        if($sql){
            echo "ok<br>";
            Echo "<a href='consultaproduto.php'>voltar</a>";
        }else{
            echo "Não ok";
        }
?>