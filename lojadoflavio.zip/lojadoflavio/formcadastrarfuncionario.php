
<?php
include('menu.php');
?>
<!DOCTYPE html>
<br>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Painel</title>
</head>
<body>
<br>
    <form method = "post" action = "cadastrarfuncionario.php"> 
    Digite o código do funcionário: 
    <input type = "text" name = "codfuncionario"><br>
    Digite o nome: 
    <input type = "text" name = "nome"><br>
    Digite o cpf do funcionário: 
    <input type = "text" name = "cpf"><br>
    Digite o telefone: 
    <input type = "text" name = "telefone"><br>
    Digite o setor: 
    <input type = "text" name = "setor"><br>
    <input type = "submit" value = "Cadastrar">

</body>
</html>