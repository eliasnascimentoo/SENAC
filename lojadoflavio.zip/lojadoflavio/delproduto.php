<?php
include('connect.php');
include('menu.php');
$codproduto = $_POST['codproduto'];
$sql = mysqli_query($conexao,"select * from estoque where codproduto = '$codproduto'");
while($linha = mysqli_fetch_array($sql)){

    $codproduto = $linha['codproduto'];
    $nome = $linha['nome'];
    $fabricante = $linha['fabricante'];
    $validade = $linha['validade'];
    $valor = $linha['valor'];

    echo "<table border = 1><tr><td>Código do Produto </td><td> $codproduto</td></tr>";
    echo "<tr><td>Nome </td>  <td> $nome</td></tr>";
    echo "<tr><td>Fabricante </td> <td> $fabricante</td></tr>";
    echo "<tr><td>Validade </td> <td> $validade</td></tr>";
    echo "<tr><td>Valor </td> <td> $valor</td></tr></table>";

//envio do dados para deletar
echo "Deseja deletar o produto ".$nome."</br></br>";
echo "<a href='deletarproduto.php?codproduto=".$codproduto."'>sim</a>";
}
echo "<br>";
echo "<br><a href ='alterarproduto.php?codproduto=".$linha['codproduto']."'>editar</a>";
Echo "<a href='busca_del_produto.php'>voltar</a>";
?>