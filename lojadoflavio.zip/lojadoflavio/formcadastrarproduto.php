
<?php
include('menu.php');
?>
<!DOCTYPE html>
<br>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Painel</title>
</head>
<body>
<br>
    <form method = "post" action = "cadastrarproduto.php"> 
    Código do produto: 
    <input type = "text" name = "codproduto" required><br>
    Digite o nome: 
    <input type = "text" name = "nome" required><br>
    Digite o fabricante do produto:
    <input type = "text" name = "fabricante" required><br>
    Digite a validade do produto: 
    <input type = "text" name = "validade" required><br>
    Digite o valor do produto:
    <input type = "text" name = "valor" required><br>
    <input type = "submit" value = "Cadastrar">

</body>
</html>