<?php
$conexao = new mysqli('localhost','root','','controledeestoque');

if(!$conexao){
    die("Não consegui fazer a conexão".mysqli_error()."<br>");

}
?>