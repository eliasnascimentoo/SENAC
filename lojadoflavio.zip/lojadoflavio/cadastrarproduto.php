<?php
include('menu.php');
include('connect.php');

$codproduto = $_POST['codproduto'];
$nome = $_POST['nome'];
$fabricante = $_POST['fabricante'];
$validade = $_POST['validade'];
$valor = $_POST['valor'];

$adc = "INSERT INTO estoque(codproduto,nome,fabricante,validade,valor) 
VALUES ('".$codproduto."','".$nome."','".$fabricante."','".$validade."','".$valor."')";

$ins = mysqli_query($conexao,$adc);

if($ins){
echo "<br>Produto cadastrado com sucesso";
echo "<br>";
}
?>