<?php
include ('connect.php');
$user = $_POST['email'];
$senha = $_POST['senha'];
$sql = mysqli_query($conexao, "select * from tlogin where email = '$user' and senha = '$senha'");
if(mysqli_num_rows($sql) >0){
    header('location: menu.php');
    exit();
}else{
    echo "Usuário ou senha inválidos";
    exit();
}
?>