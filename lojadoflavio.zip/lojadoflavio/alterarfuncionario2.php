<
<?php
        include('menu.php');
        include('connect.php');
        $codfuncionario = $_POST['codfuncionario'];
        $nome = $_POST['nome'];
        $cpf = $_POST['cpf'];
        $telefone = $_POST['telefone'];
        $setor = $_POST['setor'];

        $sql = mysqli_query($conexao,"update funcionario set nome = '$nome' where codfuncionario = $codfuncionario");
        $sql1 = mysqli_query($conexao,"update funcionario set cpf = '$cpf' where codfuncionario = $codfuncionario");
        $sql2 = mysqli_query($conexao,"update funcionario set telefone = '$telefone' where codfuncionario = $codfuncionario");
        $sql3 = mysqli_query($conexao,"update funcionario set setor = '$setor' where codfuncionario = $codfuncionario");

        if($sql){
            echo "ok<br>";
            Echo "<a href='alterarfuncionario.php'>voltar</a>";
        }else{
            echo "Não ok";
        }
?>