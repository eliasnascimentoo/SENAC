<?php
include('connect.php');
include('menu.php');
$codfuncionario = $_POST['codfuncionario'];
$sql = mysqli_query($conexao,"select * from funcionario where codfuncionario = '$codfuncionario'");
while($linha = mysqli_fetch_array($sql)){

    $codfuncionario = $linha['codfuncionario'];
    $nome = $linha['nome'];
    $cpf = $linha['cpf'];
    $telefone = $linha['telefone'];
    $setor = $linha['setor'];

echo "<table border = 1><tr><td>Código do Funcionário </td><td> $codfuncionario</td></tr>";
echo "<tr><td>Nome </td>  <td> $nome</td></tr>";
echo "<tr><td>CPF </td> <td> $cpf</td></tr>";
echo "<tr><td>Telefone </td> <td> $telefone</td></tr>";
echo "<tr><td>Setor </td> <td> $setor</td></tr></table>";

//envio do dados para deletar
echo "Deseja deletar o produto ".$nome."</br></br>";
echo "<a href='deletarfuncionario.php?codfuncionario=".$codfuncionario."'>sim</a>";
}
echo "<br>";
echo "<br><a href ='alterarfuncionario.php?codfuncionario=".$linha['codfuncionario']."'>editar</a>";
Echo "<a href='busca_del_funcionario.php'>voltar</a>";
?>