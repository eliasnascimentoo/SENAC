<?php
session_start();
$email = $_POST['email'];
$senha = $_POST['senha'];
include('connect.php');
$sql = mysqli_query($conexao, "SELECT * from tlogin where email = '$email' and senha = '$senha'");
if(mysqli_num_rows($sql) > 0){
    $_SESSION['email'] = $email;
    $_SESSION['senha'] = $senha;
    header('location: menu.php');
}
else{
    unset($_SESSION['email']);
    unset($_SESSION['senha']);
    header('location: login.html');
}
?>