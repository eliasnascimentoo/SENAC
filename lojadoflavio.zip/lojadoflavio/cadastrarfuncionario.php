<?php
include('menu.php');
include('connect.php');

$codfuncionario = $_POST['codfuncionario'];
$nome = $_POST['nome'];
$cpf = $_POST['cpf'];
$telefone = $_POST['telefone'];
$setor = $_POST['setor'];

$adc = "INSERT INTO funcionario(codfuncionario,nome,cpf,telefone,setor) 
VALUES ('".$codfuncionario."','".$nome."','".$cpf."','".$telefone."','".$setor."')";

$ins = mysqli_query($conexao,$adc);

if($ins){
echo "<br>Cadastrado com sucesso";
}
?>