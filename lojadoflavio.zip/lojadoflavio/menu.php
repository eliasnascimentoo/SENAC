<?php
session_start();
if((!isset ($_SESSION['email']) == true) and (!isset ($_SESSION['senha']) ==true)){
    unset($_SESSION['email']);
    unset($_SESSION['senha']);

    header('location: login.html');
    }

    $logado = $_SESSION['email'];
    ?>
<!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Page Title</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
        <script src="main.js"></script>
    </head>
    <body>
        <div style = "margin-bottom: 20px;">
        <h1>Loja do Flávio</h1>
        <hr>
        <a href = "menu.php">Início</a> | <a href = "formcadastrarfuncionario.php">Cadastrar Funcionário</a> |<a href = "formcadastrarproduto.php">Cadastrar Produto</a> | <a href = "consultafuncionario.php">Consultar Funcionário</a> | <a href = "consultaproduto.php">Consultar Produto</a> | <a href = "buscafuncionario.php">Buscar Funcionario</a>  | <a href = "buscaproduto.php">Buscar Produto</a> | <a href = "busca_del_funcionario.php">Excluir Funcionario</a> | <a href = "busca_del_produto.php">Excluir Produto</a> | <a href = "logout.php">Logout</a>
</div>
    </body>

    </html>